
var $div = document.getElementsByClassName('.row'); 
var $win = $(window);


$win.on('scroll', function () {
	console.log('Scrolling!');
});

$(window).on("load", function(){
	$(window).scroll(function(){
		var windowButton = $(this).scrollTop() + $(this).innerHeight();
		$(".column").each(function(){
			var objectBottom = $(this).offset().top + $(this).outerHeight();

			if (objectBottom < windowButton) {
				if ($(this).css("opacity")==0) {$(this).fadeTo(500,1);}
			}
			else {
				if($(this).css("opacity")==1) {$(this).fadeTo(500,0);}
			}
		});
	});scroll();
});


$(window).on("load", function(){
	$(window).scroll(function(){
		var windowButton = $(this).scrollTop() + $(this).innerHeight();
		$(".content").each(function(){
			var objectBottom = $(this).offset().top + $(this).outerHeight();

			if (objectBottom < windowButton) {
				if ($(this).css("opacity")==0) {$(this).fadeTo(500,1);}
			}
			else {
				if($(this).css("opacity")==1) {$(this).fadeTo(500,0);}
			}
		});
	});scroll();
});

$(window).on("load", function(){
	$(window).scroll(function(){
		var windowButton = $(this).scrollTop() + $(this).innerHeight();
		$('h2').each(function(){
			var objectBottom = $(this).offset().top + $(this).outerHeight();

			if (objectBottom < windowButton) {
				if ($(this).css("opacity")==0) {$(this).fadeTo(500,1);}
			}
			else {
				if($(this).css("opacity")==1) {$(this).fadeTo(500,0);}
			}
		});
	});scroll();
});

/*$(document).on("load",function(){
	$("#reponsive").fadeIn(3000)
})*/